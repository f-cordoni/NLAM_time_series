# prova commento
require("tseries")
require(NonlinearTSA)
require("np")
library(dHSIC)
require(gam)
require(gptk)


library(mgcv)

source("../VAR_IRFs_test/RESIT.R")


# generate VAR- TS with nonlinear contemporaneous effects


set.seed(2021)


 
source("../VAR_IRFs_test/RESIT.R", local = TRUE)

source("../VAR_IRFs_test/condIRFs_functions.R",local = TRUE)
out_shocks_resit = get_structural_shocks_RESIT(residual)


E_resit = out_shocks_resit$Structural_shocks
phi_resit = out_shocks_resit$phi 
parents_resit = out_shocks_resit$parents


ORACLE = parents_resit


#perform a bootstrap to generate a new time series and estimate Y_t
Nboot = 5
#set parameter of IRFs
N = ncol(DATA)

require(igraph)
pi = t(as.matrix(topo_sort(graph.adjacency(ORACLE))))
  

Y = DATA[,pi]
#permute following the topological order 

model_var = lineVar(Y,lag = lag,include = "none")

#get the matrices 
A = list()
for (ii in 1:lag){
  A[[ii]] = matrix(0,nrow = 3,ncol = 3)
  
  A[[ii]]   = model_var$coefficients[,((ii-1)*3+1):(ii*3)]# 4:6 # 7 : 9
  
}
residual = residuals(model_var)

out_shocks_resit = get_structural_shocks_RESIT(residual,
                                               flag_oracle = 1, oracle = ORACLE[pi,pi])


E_resit = out_shocks_resit$Structural_shocks
phi_resit = out_shocks_resit$phi 
parents_resit = out_shocks_resit$parents

t_star = 4
T_horizon =t_star+ 20
k_star = 2
H = T_horizon 
delta =   1

source("g_irfs_for fixed_A.R")
source("plot_irfs_empirical.R")

delta =   -1

source("g_irfs_for fixed_A.R")
source("plot_irfs_empirical.R")
#fare delta +/- 1 che otteniamo effetti diversi
  

#estimate CONDIRFS from RESIT and Cholesky


irf_RESIT_boot = array(0,dim= c(T_horizon-t_star+1,N,N,Nboot) )
irf_sr_boot = irf_RESIT_boot

source("aux_boot.R")
