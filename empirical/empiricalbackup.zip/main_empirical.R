setwd("~/Dropbox/post-doc/non-linearity/code/simulations_comparison/empirical")

flag_monthly = 1
setwd("data/")
source("data_pre_processing.R")
setwd("../")

# try the application where 
#[o_t  energy co2] monthly

# variable selections 
#DATA = DATA_TS[,c("RealGDP","Energy","Total_CO2_Emissions")]
  DATA = DATA_TS[,c("PGDP","RealGDP","FEDFUNDS")]

#demean the data
  scales = apply(DATA,2,sd)
DATA = scale(DATA, center = TRUE, scale = TRUE)

#select VAR order
require(vars)

VARselect(DATA)$selection
# looking at AIC (BIC)  lag  = 6
#estimate VAR withouth interecpt since we have demeaned data
lag = 3

require(tsDyn)
model_var = lineVar(DATA,lag = lag,include = "const")

#get the matrices 
A = list()
for (ii in 1:lag){
  A[[ii]] = matrix(0,nrow = 3,ncol = 3)
  
    A[[ii]]   = model_var$coefficients[,((ii-1)*3+1):(ii*3)]# 4:6 # 7 : 9
  
}
residual = residuals(model_var)
Omega = cov(residual)
residual_orig = residual

#launch RESIT


